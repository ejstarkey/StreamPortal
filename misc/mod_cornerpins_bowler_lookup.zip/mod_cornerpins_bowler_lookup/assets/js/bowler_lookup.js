function initBowlerLookup(apiUrl) {
    jQuery('#bowler-search-form').on('submit', function(e) {
        e.preventDefault();
        const bowlerName = jQuery('#bowler_name').val().trim();
        if (!bowlerName) {
            jQuery('#lookup-result').html('<p>Please enter a bowler name.</p>');
            return;
        }
        jQuery.ajax({
            url: apiUrl, method: 'POST', data: { bowler_name: bowlerName },
            headers: { 'ngrok-skip-browser-warning': '1' },
            success: function(data) {
                if (data.error) {
                    jQuery('#lookup-result').html(`<p>${data.error}</p>`);
                } else {
                    jQuery('#lookup-result').html(`<p>${bowlerName} is on Lane ${data.lane} at ${data.time}</p>`);
                }
            },
            error: function() { jQuery('#lookup-result').html('<p>Error searching for bowler.</p>'); }
        });
    });
}