<?php defined('_JEXEC') or die; ?>
<div id="stream-tiles" class="stream-tiles">
</div>