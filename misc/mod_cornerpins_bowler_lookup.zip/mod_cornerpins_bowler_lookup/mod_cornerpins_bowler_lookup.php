<?php defined('_JEXEC') or die; 
use Joomla\CMS\HTML\HTMLHelper;
HTMLHelper::_('jquery.framework');
HTMLHelper::stylesheet('modules/mod_cornerpins_bowler_lookup/assets/css/bowler_lookup.css', ['version' => 'auto', 'relative' => true]);
$api_url = $params->get('api_url', 'https://mighty-dassie-rightly.ngrok-free.app/lookup_bowler'); ?>
<div id="bowler-lookup">
    <h2>Bowler Lookup</h2>
    <form id="bowler-search-form">
        <input type="text" id="bowler_name" placeholder="Enter bowler name" required>
        <button type="submit">Search</button>
    </form>
    <div id="lookup-result"></div>
</div>
<script defer>
jQuery(document).ready(function($) { 
    <?php include 'modules/mod_cornerpins_bowler_lookup/assets/js/bowler_lookup.js'; ?>
    initBowlerLookup('<?php echo $api_url; ?>');
});
</script>