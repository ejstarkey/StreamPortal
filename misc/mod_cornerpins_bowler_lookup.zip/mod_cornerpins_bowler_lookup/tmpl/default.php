<?php defined('_JEXEC') or die; ?>
<div id="bowler-lookup">
    <form id="bowler-search-form">
        <input type="text" id="bowler_name" placeholder="Enter bowler name" required>
        <button type="submit">Search</button>
    </form>
    <div id="lookup-result"></div>
</div>